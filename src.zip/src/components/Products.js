const Products = [
    {
        id: 1,
        Title: 'product 1',
        img: '/images/anh-nguyen-kcA-c3f_3FE-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 2,
        Title: 'product 2',
        img: '/images/annie-spratt-m1t-RJ1iCIU-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 3,
        Title: 'product 3',
        img: '/images/chris-dez-t2ZIt-WNXrk-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 4,
        Title: 'product 4',
        img: '/images/elianna-friedman-4jpNPu7IW8k-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 5,
        Title: 'product 5',
        img: '/images/fernando-andrade-nAOZCYcLND8-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 6,
        Title: 'product 6',
        img: '/images/honza-vojtek-A39EqNtDpZs-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 7,
        Title: 'product 7',
        img: '/images/irene-kredenets-zNsSGYXaeP8-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 8,
        Title: 'product 8',
        img: '/images/jonathan-pielmayer-eFFnKMiDMGc-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 9,
        Title: 'product 9',
        img: '/images/joseph-gonzalez-zcUgjyqEwe8-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 10,
        Title: 'product 10',
        img: '/images/katherine-chase-0DtoVEDaJbs-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 11,
        Title: 'product 11',
        img: '/images/mae-mu-Pvclb-iHHYY-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 12,
        Title: 'product 12',
        img: '/images/mae-mu-vbAEHCrvXZ0-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 13,
        Title: 'product 13',
        img: '/images/neha-deshmukh-GoKXJaQoLQs-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 14,
        Title: 'product 14',
        img: '/images/rodrigo-dos-reis-h3AkzboxK4Q-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 15,
        Title: 'product 15',
        img: '/images/tangerine-newt-a9rxefN9vgY-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 16,
        Title: 'product 16',
        img: '/images/vino-li-pCjw_ygKCv0-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 17,
        Title: 'product 17',
        img: '/images/zaib-tse-KVv5lFOMY1E-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 18,
        Title: 'product 17',
        img: '/images/zaib-tse-KVv5lFOMY1E-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 19,
        Title: 'product 17',
        img: '/images/zaib-tse-KVv5lFOMY1E-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 20,
        Title: 'product 17',
        img: '/images/zaib-tse-KVv5lFOMY1E-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 21,
        Title: 'product 17',
        img: '/images/zaib-tse-KVv5lFOMY1E-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 22,
        Title: 'product 17',
        img: '/images/zaib-tse-KVv5lFOMY1E-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 23,
        Title: 'product 17',
        img: '/images/zaib-tse-KVv5lFOMY1E-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 24,
        Title: 'product 17',
        img: '/images/zaib-tse-KVv5lFOMY1E-unsplash.jpg',
        Price:  10,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    {
        id: 25,
        Title: 'product 17',
        img: '/images/zaib-tse-KVv5lFOMY1E-unsplash.jpg',
        Price:  1000000,
        cat: 'fruit',
        graph : '/images/basic-line-chart.svg'

    },
    
]

export default Products;