/*import React from 'react';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { CartProvider } from './components/CartContext';
import App from './App';
*/
//tests wether the app renders without crashing
//wraps app components insisde cartprovider 
///////////////test not working!!!!!///////////
/*
test('renders Home page on default route', () => {
  render(
    <CartProvider>
      <MemoryRouter initialEntries={['/']}>
        <App />
      </MemoryRouter>
    </CartProvider>
  );
  // Assuming Home component displays a welcome message:
  expect(screen.getByText(/Welcome/i)).toBeInTheDocument();
});
*/
